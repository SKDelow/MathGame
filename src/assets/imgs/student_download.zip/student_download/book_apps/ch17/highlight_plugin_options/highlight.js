"use strict";
$(document).ready(function() {
    $("nav").highlightMenu({
		useMouseOut: true
    });
}); // end ready