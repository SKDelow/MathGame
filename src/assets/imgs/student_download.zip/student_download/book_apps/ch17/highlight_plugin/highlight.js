"use strict";
$(document).ready(function() {
    $("nav").highlightMenu();
}); // end ready