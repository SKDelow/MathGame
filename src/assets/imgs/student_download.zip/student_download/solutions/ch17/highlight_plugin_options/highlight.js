"use strict";
$(document).ready(function() {
    $("nav").highlightMenu({
        mouseoverClass: "mouseover_changes",
        mouseoutClass: "mouseout_changes",
        useMouseout: true
    });
}); // end ready