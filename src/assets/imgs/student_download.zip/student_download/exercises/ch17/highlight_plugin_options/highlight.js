"use strict";
$(document).ready(function() {
    $("nav").highlightMenu({
        useMouseout: false
    });
}); // end ready